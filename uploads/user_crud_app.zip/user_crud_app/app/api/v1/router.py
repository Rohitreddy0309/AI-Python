from fastapi import APIRouter

from app.api.v1.routes import user

router = APIRouter()
router.include_router(user.router)
