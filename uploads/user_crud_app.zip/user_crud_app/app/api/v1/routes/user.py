import logging

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.schemas.user import UserCreateSchema, UserResponseSchema, UserUpdateSchema
from app.services.user_service import UserService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/users", tags=["Users"])


@router.post(
    "",
    response_model=UserResponseSchema,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new user",
)
def create_user(
    payload: UserCreateSchema,
    db: Session = Depends(get_db),
) -> UserResponseSchema:
    """Create a new user. Returns 409 if the email is already registered."""
    service = UserService(db)
    return service.create_user(payload)


@router.get(
    "",
    response_model=list[UserResponseSchema],
    status_code=status.HTTP_200_OK,
    summary="List all users",
)
def list_users(db: Session = Depends(get_db)) -> list[UserResponseSchema]:
    """Return a list of all users in the system."""
    service = UserService(db)
    return service.list_users()


@router.get(
    "/{user_id}",
    response_model=UserResponseSchema,
    status_code=status.HTTP_200_OK,
    summary="Get a user by ID",
)
def get_user(user_id: int, db: Session = Depends(get_db)) -> UserResponseSchema:
    """Retrieve a single user by their ID. Returns 404 if not found."""
    service = UserService(db)
    return service.get_user_by_id(user_id)


@router.put(
    "/{user_id}",
    response_model=UserResponseSchema,
    status_code=status.HTTP_200_OK,
    summary="Update a user",
)
def update_user(
    user_id: int,
    payload: UserUpdateSchema,
    db: Session = Depends(get_db),
) -> UserResponseSchema:
    """Partially update a user's name or active status. Returns 404 if not found."""
    service = UserService(db)
    return service.update_user(user_id, payload)


@router.delete(
    "/{user_id}",
    response_model=UserResponseSchema,
    status_code=status.HTTP_200_OK,
    summary="Soft-delete a user",
)
def delete_user(user_id: int, db: Session = Depends(get_db)) -> UserResponseSchema:
    """Deactivate a user (soft delete — sets is_active=false). Returns 404 if not found."""
    service = UserService(db)
    return service.delete_user(user_id)
