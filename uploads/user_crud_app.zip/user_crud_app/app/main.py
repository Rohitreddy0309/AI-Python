import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.api.v1.router import router as api_v1_router
from app.core.config import settings
from app.core.database import Base, engine
from app.utils.constants import API_V1_PREFIX
from app.utils.exceptions import DuplicateEntryException, NotFoundException

# ---------------------------------------------------------------------------
# Logging configuration
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Create all tables on startup (development convenience)
# ---------------------------------------------------------------------------
Base.metadata.create_all(bind=engine)

# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "A professional User CRUD API built with FastAPI, SQLAlchemy, and Pydantic v2. "
        "Follows layered architecture: Router → Service → Repository."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
)

app.include_router(api_v1_router, prefix=API_V1_PREFIX)


# ---------------------------------------------------------------------------
# Global exception handlers — map domain exceptions to HTTP responses
# ---------------------------------------------------------------------------

@app.exception_handler(NotFoundException)
async def not_found_exception_handler(request: Request, exc: NotFoundException) -> JSONResponse:
    """Convert NotFoundException to HTTP 404."""
    logger.warning("Resource not found: %s", exc.message)
    return JSONResponse(status_code=404, content={"detail": exc.message})


@app.exception_handler(DuplicateEntryException)
async def duplicate_entry_exception_handler(request: Request, exc: DuplicateEntryException) -> JSONResponse:
    """Convert DuplicateEntryException to HTTP 409."""
    logger.warning("Duplicate entry: %s", exc.message)
    return JSONResponse(status_code=409, content={"detail": exc.message})


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.get("/health", tags=["Health"])
def health_check() -> dict:
    """Confirm the API is running."""
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION}
