from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class UserCreateSchema(BaseModel):
    """Schema for creating a new user. All fields are required."""

    name: str = Field(..., min_length=1, max_length=100, examples=["Alice Smith"])
    email: EmailStr = Field(..., examples=["alice@example.com"])


class UserUpdateSchema(BaseModel):
    """Schema for updating a user. All fields are optional (partial update)."""

    name: str | None = Field(default=None, min_length=1, max_length=100, examples=["Alice Johnson"])
    is_active: bool | None = Field(default=None, examples=[True])


class UserResponseSchema(BaseModel):
    """Schema returned in all user API responses."""

    id: int
    name: str
    email: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}
