import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.database import Base, get_db
from app.main import app

# ---------------------------------------------------------------------------
# Test database setup — in-memory SQLite, isolated per test session
# ---------------------------------------------------------------------------
TEST_DATABASE_URL = "sqlite:///./test_users.db"

test_engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(autouse=True)
def reset_db():
    """Create tables before each test and drop them after."""
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)


client = TestClient(app)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def create_sample_user(name: str = "Alice", email: str = "alice@example.com") -> dict:
    response = client.post("/api/v1/users", json={"name": name, "email": email})
    return response


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------

class TestCreateUser:
    def test_create_user_returns_201(self):
        response = create_sample_user()
        assert response.status_code == 201

    def test_create_user_returns_correct_fields(self):
        response = create_sample_user()
        data = response.json()
        assert data["name"] == "Alice"
        assert data["email"] == "alice@example.com"
        assert data["is_active"] is True
        assert "id" in data
        assert "created_at" in data

    def test_create_user_duplicate_email_returns_409(self):
        create_sample_user()
        response = create_sample_user()  # Same email
        assert response.status_code == 409

    def test_create_user_missing_name_returns_422(self):
        response = client.post("/api/v1/users", json={"email": "x@x.com"})
        assert response.status_code == 422

    def test_create_user_invalid_email_returns_422(self):
        response = client.post("/api/v1/users", json={"name": "Bob", "email": "not-an-email"})
        assert response.status_code == 422


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------

class TestGetUser:
    def test_get_user_by_id_returns_200(self):
        created = create_sample_user().json()
        response = client.get(f"/api/v1/users/{created['id']}")
        assert response.status_code == 200
        assert response.json()["id"] == created["id"]

    def test_get_user_not_found_returns_404(self):
        response = client.get("/api/v1/users/999")
        assert response.status_code == 404

    def test_list_users_returns_all(self):
        create_sample_user("Alice", "alice@example.com")
        create_sample_user("Bob", "bob@example.com")
        response = client.get("/api/v1/users")
        assert response.status_code == 200
        assert len(response.json()) == 2

    def test_list_users_empty_returns_empty_list(self):
        response = client.get("/api/v1/users")
        assert response.status_code == 200
        assert response.json() == []


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------

class TestUpdateUser:
    def test_update_user_name_returns_200(self):
        created = create_sample_user().json()
        response = client.put(f"/api/v1/users/{created['id']}", json={"name": "Alice Updated"})
        assert response.status_code == 200
        assert response.json()["name"] == "Alice Updated"

    def test_update_user_is_active_returns_200(self):
        created = create_sample_user().json()
        response = client.put(f"/api/v1/users/{created['id']}", json={"is_active": False})
        assert response.status_code == 200
        assert response.json()["is_active"] is False

    def test_update_user_not_found_returns_404(self):
        response = client.put("/api/v1/users/999", json={"name": "Ghost"})
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# DELETE (Soft Delete)
# ---------------------------------------------------------------------------

class TestDeleteUser:
    def test_delete_user_returns_200(self):
        created = create_sample_user().json()
        response = client.delete(f"/api/v1/users/{created['id']}")
        assert response.status_code == 200

    def test_delete_user_sets_is_active_false(self):
        created = create_sample_user().json()
        client.delete(f"/api/v1/users/{created['id']}")
        fetched = client.get(f"/api/v1/users/{created['id']}").json()
        assert fetched["is_active"] is False

    def test_delete_user_not_found_returns_404(self):
        response = client.delete("/api/v1/users/999")
        assert response.status_code == 404
