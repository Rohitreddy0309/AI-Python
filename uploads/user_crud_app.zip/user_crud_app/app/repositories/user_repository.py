import logging

from sqlalchemy.orm import Session

from app.models.user import User
from app.schemas.user import UserCreateSchema, UserUpdateSchema

logger = logging.getLogger(__name__)


class UserRepository:
    """Handles all database operations for the User model."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, user_data: UserCreateSchema) -> User:
        """
        Persist a new user record to the database.

        Args:
            user_data (UserCreateSchema): Validated user creation payload.

        Returns:
            User: The newly created user ORM instance.
        """
        new_user = User(name=user_data.name, email=user_data.email)
        self.db.add(new_user)
        self.db.commit()
        self.db.refresh(new_user)
        logger.info("User created in DB", extra={"user_id": new_user.id})
        return new_user

    def get_by_id(self, user_id: int) -> User | None:
        """
        Fetch a single user by primary key.

        Args:
            user_id (int): The user's primary key.

        Returns:
            User | None: The user instance or None if not found.
        """
        return self.db.query(User).filter(User.id == user_id).first()

    def get_by_email(self, email: str) -> User | None:
        """
        Fetch a user by their email address.

        Args:
            email (str): Email address to search.

        Returns:
            User | None: The user instance or None if not found.
        """
        return self.db.query(User).filter(User.email == email).first()

    def get_all(self) -> list[User]:
        """
        Retrieve all user records from the database.

        Returns:
            list[User]: A list of all user ORM instances.
        """
        return self.db.query(User).all()

    def update(self, user: User, update_data: UserUpdateSchema) -> User:
        """
        Apply a partial update to an existing user record.

        Args:
            user (User): The existing user ORM instance.
            update_data (UserUpdateSchema): Fields to update (only non-None values applied).

        Returns:
            User: The updated user ORM instance.
        """
        # Only apply fields explicitly provided by the caller
        update_fields = update_data.model_dump(exclude_none=True)
        for field, value in update_fields.items():
            setattr(user, field, value)

        self.db.commit()
        self.db.refresh(user)
        logger.info("User updated in DB", extra={"user_id": user.id})
        return user

    def soft_delete(self, user: User) -> User:
        """
        Deactivate a user instead of permanently removing the record.

        Args:
            user (User): The user ORM instance to deactivate.

        Returns:
            User: The deactivated user ORM instance.
        """
        # Soft delete: mark inactive rather than destroying the record
        user.is_active = False
        self.db.commit()
        self.db.refresh(user)
        logger.info("User soft-deleted in DB", extra={"user_id": user.id})
        return user
