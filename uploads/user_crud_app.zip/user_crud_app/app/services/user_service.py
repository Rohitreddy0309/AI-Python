import logging

from sqlalchemy.orm import Session

from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.user import UserCreateSchema, UserUpdateSchema
from app.utils.constants import DUPLICATE_EMAIL_MSG, USER_NOT_FOUND_MSG
from app.utils.exceptions import DuplicateEntryException, NotFoundException

logger = logging.getLogger(__name__)


class UserService:
    """Encapsulates all business logic for User operations."""

    def __init__(self, db: Session):
        self.repository = UserRepository(db)

    def create_user(self, user_data: UserCreateSchema) -> User:
        """
        Validate and create a new user.

        Args:
            user_data (UserCreateSchema): Validated request payload.

        Returns:
            User: The newly created user.

        Raises:
            DuplicateEntryException: If the email is already registered.
        """
        self._assert_email_is_unique(user_data.email)
        logger.info("Creating user", extra={"email": user_data.email})
        return self.repository.create(user_data)

    def get_user_by_id(self, user_id: int) -> User:
        """
        Retrieve a user by ID, raising 404 if absent.

        Args:
            user_id (int): Target user's primary key.

        Returns:
            User: The matching user.

        Raises:
            NotFoundException: If no user exists with the given ID.
        """
        user = self.repository.get_by_id(user_id)
        if not user:
            raise NotFoundException(USER_NOT_FOUND_MSG.format(user_id=user_id))
        return user

    def list_users(self) -> list[User]:
        """
        Return all users in the system.

        Returns:
            list[User]: All user records.
        """
        return self.repository.get_all()

    def update_user(self, user_id: int, update_data: UserUpdateSchema) -> User:
        """
        Apply a partial update to an existing user.

        Args:
            user_id (int): Target user's primary key.
            update_data (UserUpdateSchema): Fields to update.

        Returns:
            User: The updated user.

        Raises:
            NotFoundException: If no user exists with the given ID.
        """
        user = self.get_user_by_id(user_id)
        logger.info("Updating user", extra={"user_id": user_id})
        return self.repository.update(user, update_data)

    def delete_user(self, user_id: int) -> User:
        """
        Soft-delete a user by setting is_active to False.

        Args:
            user_id (int): Target user's primary key.

        Returns:
            User: The deactivated user.

        Raises:
            NotFoundException: If no user exists with the given ID.
        """
        user = self.get_user_by_id(user_id)
        logger.info("Soft-deleting user", extra={"user_id": user_id})
        return self.repository.soft_delete(user)

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _assert_email_is_unique(self, email: str) -> None:
        """
        Raise DuplicateEntryException if the email is already in use.

        Args:
            email (str): Email address to check.

        Raises:
            DuplicateEntryException: If the email already exists.
        """
        existing_user = self.repository.get_by_email(email)
        if existing_user:
            raise DuplicateEntryException(DUPLICATE_EMAIL_MSG.format(email=email))
