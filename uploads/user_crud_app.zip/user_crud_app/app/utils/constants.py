API_V1_PREFIX = "/api/v1"

# User defaults
DEFAULT_USER_IS_ACTIVE = True

# Error messages
USER_NOT_FOUND_MSG = "User with id={user_id} was not found"
DUPLICATE_EMAIL_MSG = "A user with email '{email}' already exists"
