class NotFoundException(Exception):
    """Raised when a requested resource does not exist."""

    def __init__(self, message: str = "Resource not found"):
        self.message = message
        super().__init__(self.message)


class DuplicateEntryException(Exception):
    """Raised when a unique constraint is violated (e.g., duplicate email)."""

    def __init__(self, message: str = "Resource already exists"):
        self.message = message
        super().__init__(self.message)


class InvalidInputException(Exception):
    """Raised when input data fails business-level validation."""

    def __init__(self, message: str = "Invalid input provided"):
        self.message = message
        super().__init__(self.message)
