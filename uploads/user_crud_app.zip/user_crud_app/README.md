# 🧑‍💻 User CRUD API — FastAPI

A production-grade REST API implementing full **CRUD** operations for a User resource,
built with **FastAPI**, **SQLAlchemy**, and **Pydantic v2**.

Follows the layered architecture standard:
```
Router → Service → Repository
```

---

## 📁 Project Structure

```
user_crud_app/
├── app/
│   ├── main.py                        # App entry point, exception handlers
│   ├── core/
│   │   ├── config.py                  # Settings from .env
│   │   └── database.py                # DB engine, session, Base
│   ├── api/
│   │   └── v1/
│   │       ├── router.py              # Registers all route modules
│   │       └── routes/
│   │           └── user.py            # HTTP endpoints (no business logic)
│   ├── models/
│   │   └── user.py                    # SQLAlchemy ORM model
│   ├── schemas/
│   │   └── user.py                    # Pydantic request/response schemas
│   ├── repositories/
│   │   └── user_repository.py         # All DB queries
│   ├── services/
│   │   └── user_service.py            # All business logic
│   ├── utils/
│   │   ├── exceptions.py              # Custom domain exceptions
│   │   └── constants.py               # App-wide constants
│   └── tests/
│       └── test_user.py               # Pytest test suite
├── requirements.txt
├── .env.example
└── README.md
```

---

## ⚡ Quick Start

### 1. Clone & enter the project

```bash
cd user_crud_app
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment

```bash
cp .env.example .env
# Edit .env if needed (default uses SQLite — no setup required)
```

### 5. Run the server

```bash
uvicorn app.main:app --reload
```

The API will be live at: **http://127.0.0.1:8000**

---

## 📖 Swagger UI

Open your browser at:

```
http://127.0.0.1:8000/docs
```

All endpoints are documented and testable directly in the browser.

---

## 🔗 API Endpoints

| Method   | Endpoint                   | Description              | Success | Error         |
|----------|----------------------------|--------------------------|---------|---------------|
| `POST`   | `/api/v1/users`            | Create a new user        | 201     | 409, 422      |
| `GET`    | `/api/v1/users`            | List all users           | 200     | —             |
| `GET`    | `/api/v1/users/{user_id}`  | Get user by ID           | 200     | 404           |
| `PUT`    | `/api/v1/users/{user_id}`  | Partial update (name/active) | 200 | 404, 422      |
| `DELETE` | `/api/v1/users/{user_id}`  | Soft delete (is_active=false) | 200 | 404        |
| `GET`    | `/health`                  | Health check             | 200     | —             |

---

## 🧪 Run Tests

```bash
pytest app/tests/ -v
```

---

## 📬 Postman Quick Reference

**Create User**
```
POST http://127.0.0.1:8000/api/v1/users
Content-Type: application/json

{ "name": "Alice Smith", "email": "alice@example.com" }
```

**Get User**
```
GET http://127.0.0.1:8000/api/v1/users/1
```

**Update User**
```
PUT http://127.0.0.1:8000/api/v1/users/1
Content-Type: application/json

{ "name": "Alice Johnson", "is_active": true }
```

**Delete User (Soft)**
```
DELETE http://127.0.0.1:8000/api/v1/users/1
```

---

## 🛡️ Standards Followed

- ✅ Python 3.11+
- ✅ Type hints on all functions
- ✅ Docstrings on all public functions
- ✅ No business logic in routes
- ✅ No DB queries outside repository
- ✅ Custom exceptions only (no raw raises)
- ✅ No `print()` — structured logging throughout
- ✅ No hardcoded values — constants file used
- ✅ Pydantic v2 schemas for all I/O validation
- ✅ Soft delete pattern
- ✅ Full pytest test coverage
